
def main():
    L = str(input())
    L2 = int(input())
    
    


if __name__ == "__main__":
    main()