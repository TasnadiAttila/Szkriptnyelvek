L = []
L2 = []
def beolvas():
        f = open("C:\\Users\\hallgato\\Documents\\Szkript\\zh\\Minta_Aron_XYZ789\\feladat4\\adatok.csv","r")
        line = f.readlines()
        varos = ""
        homerseklet = 0
        ido = ""
        s = ""
        t = ""
        
        for i in line:
            s = i.split(",")
            varos = s[0]
            homerseklet = s[1]
            ido = s[2]
            t = (varos,int(homerseklet),ido)
            L.append(t)
        
        for i in line:
            s = i.split(",")
            if int(s[1]) > 11:
                varos = s[0]
                homerseklet = s[1]
                ido = s[2]
                t = (varos,int(homerseklet),ido)
                L2.append(t)

        f.close()
def kiir():
    fg = open("kimenet.csv","w")
    fg.write(L2)
    fg.close()

def main():
    beolvas()
    kiir()

main()
